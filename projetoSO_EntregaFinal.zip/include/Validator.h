/*
    Projeto de Sistemas Operativos 2024/2025 - DEIChain
    Diogo Nuno Fonseca Rodrigues 2022257625
    Guilherme Teixeira Gonçalves Rosmaninho 2022257636
*/

#ifndef VALIDATOR_H
#define VALIDATOR_H

void validator(int num);

#endif // VALIDATOR_H